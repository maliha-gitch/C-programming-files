#include<stdio.h>
int main(){
int num , sum=0;
scanf("%d",&num);
if(num==1 || num==2){
   sum=sum+num;
   printf("%d\n", sum);
}
else if(num==3){
    printf("%d\n", sum);
}
else
{
    printf("%d\n", num);
}
return 0;
}
