#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);

    for (int i = 1; i <= n; i++) {
        for (int s = 1; s <= n - i; s++) {//space print
            printf("  ");
        }

        for (int j = 1; j <= 2 * i - 1; j++) {//star print
            printf("* ");
        }

        printf("\n");
    }

    return 0;
}
