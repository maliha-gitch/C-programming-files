#include<stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++)
            {
                if(i<=(n+1)/2){
                    if(i==j || i+j==n+1){
                        printf("*");
                    }
                    else{
                        printf(" ");
                    }
                }
                else{
                    if((n+1)/2==j){
                        printf("*");
                    }
                    else{
                        printf(" ");
                    }
                }
            }
            printf("\n");
    }
}
