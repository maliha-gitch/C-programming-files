#include<stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++)
            {
               if(i<=(n+1)/2){
                if(i==j || j==1 || j==n || i+j ==n+1){
                    printf("*");
                }
                else{
                    printf(" ");
                }
               }
               else{
                if(j==1 || j==n){
                    printf("*");
                }
                else{
                    printf(" ");
                }
               }
            }
            printf("\n");
    }
}
