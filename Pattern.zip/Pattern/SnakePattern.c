#include<stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++)
            {

        if(i%2==1)
        {
                printf("*");
            }
    else
        {

        if(i%4==2)
                {
                if(j==n){
                    printf("*");
                }
                else{
                    printf(" ");
                }

                 }
         else
            {
                    if(j==1){
                        printf("*");
                    }
                    else{
                        printf(" ");
                    }
                   }
                    }


            }

        printf("\n");
    }
}
