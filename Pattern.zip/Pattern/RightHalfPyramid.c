//#include<stdio.h>
//int main()
//{
//    int n;
//    scanf("%d",&n);
//    for(int i=1;i<=n;i++){
//        for(int j=1;j<=n;j++){
//                if( n-i+1<=j){
//                    printf("*");
//                }
//                else{
//                    printf(" ");
//                }
//
//        }
//
//            printf("\n");
//    }
//}


//#include<stdio.h>
//int main()
//{
//    int n;
//    scanf("%d",&n);
//    for(int i=1;i<=n;i++){
//        for(int j=1;j<=i;j++){
//             printf("*");
//
//        }
//         printf("\n");
//    }
//}



//#include<stdio.h>
//int main()
//{
//    int n;
//    scanf("%d",&n);
//    for(int i=1;i<=n;i++){
//        for(int j=n;j>=1;j--){
//
//                if(n-i+1>=j)
//                {
//
//             printf("*");
//
//        }
//        else{
//            printf(" ");
//        }
//                }
//         printf("\n");
//                }
//        }


//#include<stdio.h>
//int main()
//{
//    int n;
//    scanf("%d",&n);
//    for(int i=1;i<=n;i++){
//        for(int j=1;j<=n;j++){
//                if( n-i+1>=j){
//                    printf("*");
//                }
//                else{
//                    printf(" ");
//                }
//
//        }
//
//            printf("\n");
//    }
//}









